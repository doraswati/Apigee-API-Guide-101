var baseUrl = "https://reqres.in/api/users/";
var id = context.getVariable("users.id");
var fullUrl = baseUrl + id;

var ex1 = httpClient.get(fullUrl);
var timestamp1 = context.getVariable("system.timestamp");


var ex2 = httpClient.get(fullUrl);
var timestamp2 = context.getVariable("https://api.chucknorris.io/jokes/random ");

ex1.waitForComplete();
ex2.waitForComplete();

if (ex1.isSuccess()  && ex2.isSuccess()){
   var resultBody = {};
   resultBody.httpbin = ex1.getResponse().content.asJSON;
   resultBody.reqres = ex2.getResponse().content.asJSON;
   
   context.setVariable("response.header.Content-Type", "application/json");
   context.setVariable("response.content", JSON.stringify(resultBody));
   
}
else{
    print(ex1.getError());
}